import * as utils from './utils';


const mockData: any = [
    {
        name: "Germany",
        population: 90002,
        callingCodes: [
            "49"
        ],
    },
    {
        name: "India",
        population: 900022,
        callingCodes: [
            "42"
        ],
    },
    {
        name: "Denmark",
        population: 90001,
        callingCodes: [
            "73"
        ],
    }
];

describe('test sort function', () => {
    it("sort asc on population", () => {
        const sortedDataCheck: any = [
            {
                name: "Denmark",
                population: 90001,
                callingCodes: [
                    "73"
                ],

            },
            {
                name: "Germany",
                population: 90002,
                callingCodes: [
                    "49"
                ],
            },
            {
                name: "India",
                population: 900022,
                callingCodes: [
                    "42"
                ],
            }
        ];

        const sortedResultByUtil = utils.sortbyAscDesc(mockData, "ASC");

        expect(sortedResultByUtil).toEqual(sortedDataCheck);
    });

    it("sort asc on population", () => {
        const sortedDataCheck: any = [
            {
                name: "India",
                population: 900022,
                callingCodes: [
                    "42"
                ],
            },
            {
                name: "Germany",
                population: 90002,
                callingCodes: [
                    "49"
                ],
            },
            {
                name: "Denmark",
                population: 90001,
                callingCodes: [
                    "73"
                ],
            },


        ];

        const sortedResultByUtil = utils.sortbyAscDesc(mockData, "DESC");

        expect(sortedResultByUtil).toEqual(sortedDataCheck);
    });

});

describe("filter data", () => {
    it("should filter data by name", () => {
        const filterCheckList = [
            {
                name: "India",
                population: 900022,
                callingCodes: [
                    "42"
                ],
            },
        ]

        const filterResultByUtil = utils.filterCountries(mockData, "IN");

        expect(filterResultByUtil).toEqual(filterCheckList);
    });

    it("should filter data by callingCode", () => {
        const filterCheckList = [
            {
                name: "Denmark",
                population: 90001,
                callingCodes: [
                    "73"
                ],
            },
        ]

        const filterResultByUtil = utils.filterCountries(mockData, "73");

        expect(filterResultByUtil).toEqual(filterCheckList);
    })
})