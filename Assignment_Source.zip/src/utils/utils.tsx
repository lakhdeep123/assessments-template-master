export function filterCountries(countrylist: any, val: any) {


    const countries = countrylist.filter(function (el: any) {

        return (el.name.toLowerCase().indexOf(val.toLowerCase()) !== -1)
            || (el.callingCodes.indexOf(val) !== -1)
    });

    return countries;

}

export function sortbyAscDesc(data: any, sortbyDirection: String) {
    return populationSort(data, sortbyDirection);

}

export function populationSort(data: any, sortbyDirection: String) {
    const localDataCopy: any = [...data];
    const countries = localDataCopy.slice().sort((a: any, b: any) => {
        if (sortbyDirection == "ASC")
            return a.population - b.population;
        else if (sortbyDirection == "DESC")
            return b.population - a.population;
    });


    return countries;
}