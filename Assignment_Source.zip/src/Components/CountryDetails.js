import React, { useState, useEffect } from 'react';

import * as utils from '../utils/utils';
import countryData from '../data/countryData';

function CountryDetails() {


    const [countrylist, setFilteredCountryList] = useState([])

    const [capitalName, SetCapital] = useState("")
    const [language, SeLanguage] = useState("")
    const [currency, SetCurrency] = useState("")
    const [modalIsOpen, setModalIsOpen] = useState(false)
    const [mockData, setMockData] = useState(countryData || []);
    const [checkData, setCheckData] = useState(true);


    useEffect(() => {


        if (countrylist.length == 0 && checkData) {
            /// API No longer working so Used Json Data
            setFilteredCountryList(mockData);
        }

    }, []);

    useEffect(() => console.log(countrylist), [countrylist]);


    const handleClick = function (countryName) {
        const countryInfo = countrylist.filter(function (el) {
            return (el.name.toLowerCase().indexOf(countryName.toLowerCase()) !== -1)
        });
        SeLanguage(countryInfo[0].languages[0].name);
        SetCapital(countryInfo[0].capital);
        SetCurrency(countryInfo[0].currencies[0].symbol + countryInfo[0].currencies[0].name);
        setModalIsOpen(true);

    };

    const handleFilter = function (e) {

        setFilteredCountryList(mockData)
        const newCountriesList = utils.filterCountries(mockData, e);

        setFilteredCountryList(newCountriesList);
        setCheckData(false);
    };

    const handleAscSort = () => {
        const sortedData = utils.sortbyAscDesc(mockData, "ASC");
        setFilteredCountryList(sortedData);
    };
    const handleDescSort = () => {
        const sortedData = utils.sortbyAscDesc(mockData, "DESC");
        setFilteredCountryList(sortedData);
    };




    return (
        <div>
        <div className="container">
           <center>
              <h2>Countries Infomation Statistics</h2>
           </center>
           <div className="searchBox">
              <label>Search by Country Name or Code  </label>
              <input placeholder=" Enter Value"  type="text" onChange={e => handleFilter(e.target.value)} ></input>
           </div>
           <br/>
          
                 <table className="table table-striped ">
                    <thead>
                       <tr>
                          <th  scope="col">Country Name</th>
                          <th  scope="col">Calling Codes</th>
                          <th scope="col">Capital</th>
                          <th scope="col">
                             Population
                             </th><th>
                             Sort Population &nbsp;
                             <button className="btn btn-primary" onClick={handleAscSort} >ASC</button>&nbsp;
                             <button className="btn btn-primary" onClick={handleDescSort} >Desc</button>
                          </th>
                       </tr>
                    </thead>
                    <tbody>
                       {
                       countrylist.map((countries, idx) =>
                       <tr>
                          <td ><a href="#" className="button-default" onClick={() => handleClick(countries.name)} >{countries.name}</a></td>
                          <td >{countries.callingCodes}
                          </td>
                          <td >{countries.capital}
                          </td>
                          <td >{countries.population}</td>
                          <td>&nbsp;</td>
                       </tr>
                       )}
                    </tbody>
                 </table>
              
        </div>
        <div >
           {modalIsOpen &&
           <div className="container dvDescription">
              <div className="closeBtn">
                 <button className="btn btn-danger" onClick={() => setModalIsOpen(false)}>Close</button>
              </div>
              <table className="table table-striped ">
                 <thead>
                    <tr>
                       <th scope="col">Capital Name :</th>
                       <th scope="col"> Language :</th>
                       <th scope="col"> Currency  : </th>
                    </tr>
                 </thead>
                 <tbody>
                    <tr>
                       <td>{capitalName}</td>
                       <td>{language}</td>
                       <td>{currency}</td>
                    </tr>
                 </tbody>
              </table>
           </div>
           }
        </div>
     </div>

    )
}


export default CountryDetails;