import React from 'react';
import CountryDetails from './Components/CountryDetails';


function App() {
  return <div><CountryDetails/></div>;
}

export default App;
